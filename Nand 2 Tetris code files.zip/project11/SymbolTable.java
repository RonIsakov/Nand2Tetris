import java.util.HashMap;
import java.util.Map;

/*
 * Each symbol table can be implemented as a separate instance of SymbolTable.
 * When compiling a Jack class, we can build one class-level symbol table and one subroutine-level symbol table.
 * We can reset the latter table each time we start compiling a new subroutine.
 */
public class SymbolTable {
    private HashMap<String,Symbol> classtable; // The list of class variables.
    private HashMap<String,Symbol> methodtable; // The list of method variables.
    private HashMap<Symbol.KIND,Integer> indeices; // The list of varibles options.

    /*
     * Creates a new symbol table.
     */
    public SymbolTable() {
        classtable = new HashMap<String, Symbol>();
        methodtable = new HashMap<String, Symbol>();
        indeices = new HashMap<Symbol.KIND,Integer>();
        indeices.put(Symbol.KIND.ARG,0);
        indeices.put(Symbol.KIND.FIELD,0);
        indeices.put(Symbol.KIND.STATIC,0);
        indeices.put(Symbol.KIND.VAR,0);
    }

    /*
     * Starts a new subroutine scope.
     * Resets the subroutine's symbol table.
     */
    public void startSubroutine() {
        methodtable.clear();
        indeices.put(Symbol.KIND.VAR,0);
        indeices.put(Symbol.KIND.ARG,0);
    }

    /*
     * Defines (adds to the table) a new variable of the given name, type and kind.
     * Assigns to it the index value of that kind and adds 1 to the index.
     */
    public void define(String strName, String strType, Symbol.KIND strKind) {
        if (strKind == Symbol.KIND.ARG || strKind == Symbol.KIND.VAR){
        int index = indeices.get(strKind);
        Symbol symbol = new Symbol(strType, strKind, index);
        indeices.put(strKind, index+1);
        methodtable.put(strName,symbol);
        }
        else if(strKind.equals(Symbol.KIND.STATIC) || strKind.equals(Symbol.KIND.FIELD)) {
            int index = indeices.get(strKind);
            Symbol symbol = new Symbol(strType,strKind,index);
            indeices.put(strKind,index+1);
            classtable.put(strName, symbol);
        }
    }

    /*
     * Returns the number of variables of the given kind already defined in the table.
     */
    public int varCount(Symbol.KIND strKind) {
        return indeices.get(strKind);
    }

    /*
     * Returns the kind of the named identifier.
     * if the identifier is not found, returns NONE.
     */
    public Symbol.KIND kindOf(String name){
        Symbol symbol = Up(name);
        if (symbol != null) 
            return symbol.getKind();
        return Symbol.KIND.NONE;
    }

    /*
     * Returns the type of the named variable.
     */
     public String typeOf(String name){
        Symbol symbol = Up(name);
        if (symbol != null) 
            return symbol.getType();
        return "";
    }

    /*
     * returns the index of the named variable.
     */
    public int indexOf(String name){
        Symbol symbol = Up(name);
        if (symbol != null) 
            return symbol.getIndex();
        return -1;
    }

    /*
     * check if the symbol is exist.
     */
    private Symbol Up(String name){
        if (classtable.get(name) != null){
            return classtable.get(name);
        }
        else if (methodtable.get(name) != null){
            return methodtable.get(name);
        }
        else {
            return null;
        }
    }

}
