import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;

/*
 * A simple module that writes individual VM commands to the output .vm file
 */
public class VMWriter {
    public static enum SEGMENT {CONST,ARG,LOCAL,STATIC,THIS,THAT,POINTER,TEMP,NONE}; // Variables in the VM.
    public static enum COMMAND {ADD,SUB,NEG,EQ,GT,LT,AND,OR,NOT}; // Commands in the VM
    private static HashMap<SEGMENT,String> segmentStringHashMap = new HashMap<SEGMENT, String>(); // list of varibles.
    private static HashMap<COMMAND,String> commandStringHashMap = new HashMap<COMMAND, String>(); // list of commands.
    private PrintWriter pw; // the output, .vm file.

    static {
        segmentStringHashMap.put(SEGMENT.CONST,"constant");
        segmentStringHashMap.put(SEGMENT.ARG,"argument");
        segmentStringHashMap.put(SEGMENT.LOCAL,"local");
        segmentStringHashMap.put(SEGMENT.STATIC,"static");
        segmentStringHashMap.put(SEGMENT.THIS,"this");
        segmentStringHashMap.put(SEGMENT.THAT,"that");
        segmentStringHashMap.put(SEGMENT.POINTER,"pointer");
        segmentStringHashMap.put(SEGMENT.TEMP,"temp");

        commandStringHashMap.put(COMMAND.ADD,"add");
        commandStringHashMap.put(COMMAND.SUB,"sub");
        commandStringHashMap.put(COMMAND.NEG,"neg");
        commandStringHashMap.put(COMMAND.EQ,"eq");
        commandStringHashMap.put(COMMAND.GT,"gt");
        commandStringHashMap.put(COMMAND.LT,"lt");
        commandStringHashMap.put(COMMAND.AND,"and");
        commandStringHashMap.put(COMMAND.OR,"or");
        commandStringHashMap.put(COMMAND.NOT,"not");
    }

    /*
     * Creates a new output .vm file/stream and prepares it for writing.
     */
    public VMWriter(File Out) {
        try {
            pw = new PrintWriter(Out);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    /*
     * Writes a VM push command.
     */
    public void writePush(SEGMENT seg, int index){
        writeCommand("push",segmentStringHashMap.get(seg),String.valueOf(index));
    }

    /*
     * Writes a VM pop command.
     */
    public void writePop(SEGMENT seg, int index){
        writeCommand("pop",segmentStringHashMap.get(seg),String.valueOf(index));
    }

    /*
     * Writes a VM arithmetic-logical command.
     */
    public void writeArithmetic(COMMAND commands){
        writeCommand(commandStringHashMap.get(commands),"","");
    }

    /*
     * Writes a VM label command.
     */
    public void writeLabel(String label){
        writeCommand("label",label,"");
    }

    /*
     * Writes a VM goto command.
     */
    public void writeGoto(String label){
        writeCommand("goto",label,"");
    }

    /*
     * Writes a VM if-goto command.
     */
    public void writeIf(String label){
        writeCommand("if-goto",label,"");
    }

    /*
     * Writes a VM call command.
     */
    public void writeCall(String name, int args){
        writeCommand("call",name,String.valueOf(args));
    }

    /*
     * Writes a VM function command.
     */
    public void writeFunction(String name, int local){
        writeCommand("function",name,String.valueOf(local));
    }

    /*
     * Writes a VM return command.
     */
    public void writeReturn(){
        writeCommand("return","","");
    }

    /*
     * Writes the VM command in the output.
     */
    public void writeCommand(String str, String arg_1, String arg_2){

        pw.print(str + " " + arg_1 + " " + arg_2 + "\n");
    }

    /*
     * Closes the output file/stream.
     */
    public void close(){
        pw.close();
    }
}