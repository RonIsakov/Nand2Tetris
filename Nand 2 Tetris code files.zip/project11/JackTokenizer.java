import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* This class handels the compiler's input.
 * It provides services for: ignoring white space, getting the current token and andvancing
 * the input just byond it, getting the type of the current token.
 */

public class JackTokenizer {
    public static enum TYPE {KEYWORD, SYMBOL, IDENTIFIER, INT_CONST, STRING_CONST, NONE}; // Constant for types.
    public static enum KEYWORD {CLASS, METHOD, FUNCTION, CONSTRUCTOR, INT, BOOLEAN, CHAR, VOID,
        VAR, STATIC, FIELD, LET, DO, IF, ELSE, WHILE, RETURN, TRUE, FALSE, NULL, THIS}; // Constant for keyboard.
    private String token; // the token.
    private TYPE tokenType; // the type of the token.
    private int pointer; // the index of where we are in the file.
    private ArrayList<String> tokens; // list of tokens.
    private static Pattern tokenPatterns; // parts of token.
    private static String keywordReg; // which keyword it is.
    private static String symbolReg; // symbols.
    private static String intReg; // numbers for cnstant.
    private static String stringReg; // characters for string.
    private static String idReg; // characters for identifier.
    private static HashMap<String,KEYWORD> keyword = new HashMap<String, KEYWORD>(); // list of keywords.
    private static HashSet<Character> op = new HashSet<Character>(); // list of opreatins.
    
    static {
        keyword.put("class",KEYWORD.CLASS);
        keyword.put("constructor",KEYWORD.CONSTRUCTOR);
        keyword.put("function",KEYWORD.FUNCTION);
        keyword.put("method",KEYWORD.METHOD);
        keyword.put("field",KEYWORD.FIELD);
        keyword.put("static",KEYWORD.STATIC);
        keyword.put("var",KEYWORD.VAR);
        keyword.put("int",KEYWORD.INT);
        keyword.put("char",KEYWORD.CHAR);
        keyword.put("boolean",KEYWORD.BOOLEAN);
        keyword.put("void",KEYWORD.VOID);
        keyword.put("true",KEYWORD.TRUE);
        keyword.put("false",KEYWORD.FALSE);
        keyword.put("null",KEYWORD.NULL);
        keyword.put("this",KEYWORD.THIS);
        keyword.put("let",KEYWORD.LET);
        keyword.put("do",KEYWORD.DO);
        keyword.put("if",KEYWORD.IF);
        keyword.put("else",KEYWORD.ELSE);
        keyword.put("while",KEYWORD.WHILE);
        keyword.put("return",KEYWORD.RETURN);
        
        op.add('+');
        op.add('-');
        op.add('*');
        op.add('/');
        op.add('&');
        op.add('|');
        op.add('<');
        op.add('>');
        op.add('=');
    }

    /*
     * Opens the input .jack file/ stream and gets readt to tokenize it.
     */
    public JackTokenizer(File file) {
        try {
            Scanner scan = new Scanner(file);
            String preprocessed = "";
            String line = "";

            while(scan.hasNext()){
                line = noComments(scan.nextLine()).trim();
                if (line.length() > 0) {
                    preprocessed += line + "\n";
                }
            }
            preprocessed = noBlockComments(preprocessed).trim();
            initRegs();

            Matcher match = tokenPatterns.matcher(preprocessed);
            tokens = new ArrayList<String>();
            pointer = 0;
            while (match.find()){
                tokens.add(match.group());
            }
        } 
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        token = "";
        tokenType = TYPE.NONE;
    }

     /**
     * inti regex we need in tokenizer
     */
    private void initRegs(){
        keywordReg = "";
        for (String seg: keyword.keySet()){
            keywordReg += seg + "|";
        }
        symbolReg = "[\\&\\*\\+\\(\\)\\.\\/\\,\\-\\]\\;\\~\\}\\|\\{\\>\\=\\[\\<]";
        intReg = "[0-9]+";
        stringReg = "\"[^\"\n]*\"";
        idReg = "[a-zA-Z_]\\w*";
        tokenPatterns = Pattern.compile(idReg + "|" + keywordReg + symbolReg + "|" + intReg + "|" + stringReg);
    }

    /*
     * Are there more tokens in the input?
     */
    public boolean hasMoreTokens() {
        return (pointer < tokens.size());
    }

    /*
     * Gets the next token from the input and makes it the current token.
     * This method should be called only if hasMoreTokens is true.
     * Intially there is no current token.
     */
    public void advance(){
        if (hasMoreTokens()) {
            token = tokens.get(pointer);
            pointer++;
        }
        else {
            throw new IllegalStateException("there is no tokens");
        }

        if (token.matches(keywordReg)){
            tokenType = TYPE.KEYWORD;
        }
        else if (token.matches(symbolReg)){
            tokenType = TYPE.SYMBOL;
        }
        else if (token.matches(intReg)){
            tokenType = TYPE.INT_CONST;
        }
        else if (token.matches(stringReg)){
            tokenType = TYPE.STRING_CONST;
        }
        else if (token.matches(idReg)){
            tokenType = TYPE.IDENTIFIER;
        }
        else 
            throw new IllegalArgumentException("no such token:" + token);
    }

    /*
     * Get the current token.
     */
    public String getCurrentToken() {
        return token;
    }

    /*
     * Returns the type of the current token, as a constant.
     */
    public TYPE tokenType(){

        return tokenType;
    }


    /*
     * Returns the keyword which is the current token, as a constant.
     * This method should be called only if tokenType is KEYWORD.
     */
    public KEYWORD keyWord(){

        if (tokenType == TYPE.KEYWORD){

            return keyword.get(token);
        }
        else 
            throw new IllegalStateException("the token is not a keyword!");
    }

    /*
     * Returns the character which is the current token.
     * Should be called only if tokenType is SYMBOL.
     * 
     */
    public char symbol(){
        if (tokenType == TYPE.SYMBOL)
            return token.charAt(0);
        else
            throw new IllegalStateException("the token is not a symbol!");
        
    }

    /*
     * Returns the string which is the current token. 
     * Should be called only if tokenType is IDENTIFIER.
     */
    public String identifier(){

        if (tokenType == TYPE.IDENTIFIER)
            return token;
        else
            throw new IllegalStateException("the token is not an identifier!");
    }

    /*
     * Returns the integer value of the current token.
     * Should be called only if tokenType is INT_CONST.
     */
    public int intVal(){
        if(tokenType == TYPE.INT_CONST)
            return Integer.parseInt(token);
        else 
            throw new IllegalStateException("the token is not an integer constant!");
    }

    /*
     * Returns the string value of the current token, without the opening and closing double qoutes.
     * Should be called only if tokenType is STRING_CONST.
     */
    public String stringVal(){
        if (tokenType == TYPE.STRING_CONST)
            return token.substring(1, token.length() - 1);
        else 
            throw new IllegalStateException("the token is not a string constant!");
    }

    /**
     * move pointer back
     */
    public void pointerBack(){

        if (pointer > 0) {
            pointer--;
            token = tokens.get(pointer);
        }

    }

    /**
     * return if current symbol is a op
     * @return
     */
    public boolean isOp(){
        return op.contains(symbol());
    }

    /**
     * Delete comments(String after "//") from a String
     * @param str
     * @return
     */
    public static String noComments(String str){
        int position = str.indexOf("//");
        if (position != -1)
            str = str.substring(0, position);
        return str;
    }
    
    /**
     * Delete spaces from a String
     * @param str
     * @return
     */
    public static String noSpaces(String str){
        String result = "";
        if (str.length() != 0){
            String[] segs = str.split(" ");
            for (String s: segs){
                result += s;
            }
        }
        return result;
    }

    /**
     * delete block comment
     * @param str
     * @return
     */
    public static String noBlockComments(String str){
        int startIndex = str.indexOf("/*");
        if (startIndex == -1) 
            return str;
        String result = str;
        int endIndex = str.indexOf("*/");
        while(startIndex != -1){
            if (endIndex == -1)
                return str.substring(0,startIndex - 1);
            result = result.substring(0,startIndex) + result.substring(endIndex + 2);
            startIndex = result.indexOf("/*");
            endIndex = result.indexOf("*/");
        }
        return result;
    }
}

