/*
 * In this class we create a Symbol type object that contains the info of each line in the SymbolTable.
 */
public class Symbol {

    public static enum KIND {STATIC, FIELD, ARG, VAR, NONE}; // variable kinds.
    private String type; // variable type.
    private KIND kind; // variable kind.
    private int index; // variable number.

    /*
     * Create a Symbol type object.
     */
    public Symbol(String type, KIND kind, int index) {
        this.type = type;
        this.kind = kind;
        this.index = index;
    }

    /*
     * Get the type of the symbol.
     */
    public String getType() {
        return type;
    }

    /*
     * Get the kind of the symbol.
     */
    public KIND getKind() {
        return kind;
    }

    /*
     * Get the number of the symbol.
     */
    public int getIndex() {
        return index;
    }

    /*
     * Print the information of the symbol.
     */
    public String toString() {
        return "Symbol{" + "type='" + type + '\'' + ", kind=" + kind + ", index=" + index +'}';
    }
}